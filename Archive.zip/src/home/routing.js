import Index from './view/index.vue'

module.exports = {
    path: '/',
    component: Index
}
