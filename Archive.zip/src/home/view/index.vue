<template>
	<div>
		<p>
				Some people say the improv scene has become too colourful. Too vibrant. It is time to restore the balance...
		</p>

		<p>
				<a href="style.css">Here</a> is a link to the Dullprov website stylesheet.
		</p>
	</div>
</template>
