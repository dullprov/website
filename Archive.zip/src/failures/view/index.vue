<template>
	<div>
		List of failures
	</div>
</template>
