import Index from './view/index.vue'

module.exports = {
    path: '/failures',
    component: Index
}
